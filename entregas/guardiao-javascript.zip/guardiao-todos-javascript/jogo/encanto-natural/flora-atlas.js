"use strict";
window.GuardiaoFloraEncanto = {
  file: "../../encanto-natural/assets/encanto-flora.webp",
  width: 1424,
  height: 1136,
  referenceHeight: 239.0,
  frames: [
    { bounds: [32, 17, 293, 255], pivot: [178.5, 272] },
    { bounds: [382, 36, 303, 236], pivot: [533.5, 272] },
    { bounds: [726, 30, 328, 242], pivot: [890.0, 272] },
    { bounds: [1100, 29, 293, 243], pivot: [1246.5, 272] },
    { bounds: [64, 299, 229, 257], pivot: [178.5, 556] },
    { bounds: [391, 317, 286, 239], pivot: [534.0, 556] },
    { bounds: [726, 318, 329, 238], pivot: [890.5, 556] },
    { bounds: [1096, 322, 300, 234], pivot: [1246.0, 556] },
    { bounds: [31, 590, 294, 250], pivot: [178.0, 840] },
    { bounds: [376, 603, 315, 237], pivot: [533.5, 840] },
    { bounds: [744, 597, 291, 243], pivot: [889.5, 840] },
    { bounds: [1152, 603, 188, 237], pivot: [1246.0, 840] },
    { bounds: [84, 886, 188, 238], pivot: [178.0, 1124] },
    { bounds: [440, 884, 189, 240], pivot: [534.5, 1124] },
    { bounds: [745, 880, 290, 244], pivot: [890.0, 1124] },
    { bounds: [1087, 887, 318, 237], pivot: [1246.0, 1124] },
  ],
};
if (window.GuardiaoVidaAtlas)
  window.GuardiaoVidaAtlas.flora = window.GuardiaoFloraEncanto;
